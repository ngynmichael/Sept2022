package com.saran.model;

import lombok.Data;

@Data
public class Employee {
	
	private int empId=123;

}
