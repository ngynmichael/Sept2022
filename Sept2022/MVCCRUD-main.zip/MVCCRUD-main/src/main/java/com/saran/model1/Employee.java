package com.saran.model1;

//POJO
public class Employee {

}
